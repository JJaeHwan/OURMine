package kr.or.ddit.validate;

import javax.validation.groups.Default;

/**
 * 수정이라는 business logic 에 대해 적용할 그룹 힌트.
 *
 */
public interface UpdateGroup extends Default{}
