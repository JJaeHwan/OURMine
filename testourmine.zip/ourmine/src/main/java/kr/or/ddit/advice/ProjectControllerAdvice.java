package kr.or.ddit.advice;


import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice("kr.or.ddit.project")
public class ProjectControllerAdvice {



}
