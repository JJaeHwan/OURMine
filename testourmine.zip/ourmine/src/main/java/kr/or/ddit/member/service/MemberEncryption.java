package kr.or.ddit.member.service;

public interface MemberEncryption {
	
	
	public String encode(String memberPassword);
}
